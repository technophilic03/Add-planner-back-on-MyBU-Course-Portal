// ==UserScript==
// @name         Change Shopping Cart to Planner
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Change the text "Shopping Cart" to "Planner" on MyBU portal
// @author       Anon_Andy and ChatGPT
// @match        https://mybustudent.bu.edu/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to replace the text
    function replaceTextOnPage(oldText, newText) {
        const findAndReplace = (node) => {
            if (node.nodeType === 3) { // Text node
                const value = node.nodeValue;
                const newValue = value.replace(oldText, newText);
                if (newValue !== value) {
                    node.nodeValue = newValue;
                }
            } else if (node.nodeType === 1) { // Element node
                for (let i = 0; i < node.childNodes.length; i++) {
                    findAndReplace(node.childNodes[i]);
                }
            }
        };

        findAndReplace(document.body);
    }

    // Replace "Shopping Cart" with "Planner"
    replaceTextOnPage('Shopping Cart', 'Planner');

    // Observe for changes in the document and apply the replacement for dynamic content
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.addedNodes && mutation.addedNodes.length > 0) {
                for (let i = 0; i < mutation.addedNodes.length; i++) {
                    const newNode = mutation.addedNodes[i];
                    replaceTextOnPage('Shopping Cart', 'Planner', newNode);
                    replaceTextOnPage('You have no classes in your shopping cart.', 'Your planner is empty.', newNode);
                    replaceTextOnPage('You do not have any classes in your cart.', 'Your planner is empty.', newNode);
                }
            }
        });
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();
